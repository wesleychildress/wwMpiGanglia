#!/bin/sh

if [ -x "/usr/bin/cluster-env" ]; then
   /usr/bin/cluster-env
fi
